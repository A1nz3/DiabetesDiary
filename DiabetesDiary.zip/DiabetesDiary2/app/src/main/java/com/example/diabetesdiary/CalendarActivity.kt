package com.example.diabetesdiary

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.*

class CalendarActivity : AppCompatActivity() {

    private lateinit var calendarView: CalendarView
    private lateinit var selectedDateText: TextView
    private lateinit var noteInput: EditText
    private lateinit var addNoteButton: Button
    private lateinit var notesListView: ListView

    private lateinit var adapter: ArrayAdapter<String>

    private var selectedDate: String = ""

    private val db = FirebaseFirestore.getInstance()
    private val auth = FirebaseAuth.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_calendar)

        calendarView = findViewById(R.id.calendarView)
        selectedDateText = findViewById(R.id.selectedDateText)
        noteInput = findViewById(R.id.noteInput)
        addNoteButton = findViewById(R.id.addNoteButton)
        notesListView = findViewById(R.id.notesListView)

        selectedDate = formatDate(calendarView.date)
        selectedDateText.text = "Wybrana data: $selectedDate"

        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, mutableListOf())
        notesListView.adapter = adapter

        calendarView.setOnDateChangeListener { _, year, month, dayOfMonth ->
            selectedDate = String.format("%04d-%02d-%02d", year, month + 1, dayOfMonth)
            selectedDateText.text = "Wybrana data: $selectedDate"
            loadNotesForDate(selectedDate)
        }

        addNoteButton.setOnClickListener {
            val noteText = noteInput.text.toString().trim()
            if (noteText.isNotEmpty()) {
                addNoteForDateFirestore(selectedDate, noteText)
            } else {
                Toast.makeText(this, "Wpisz treść notatki", Toast.LENGTH_SHORT).show()
            }
        }

        loadNotesForDate(selectedDate)
    }

    private fun formatDate(millis: Long): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        return sdf.format(Date(millis))
    }

    private fun loadNotesForDate(date: String) {
        val currentUser = auth.currentUser
        if (currentUser == null) {
            Toast.makeText(this, "Nie jesteś zalogowany", Toast.LENGTH_SHORT).show()
            adapter.clear()
            return
        }

        db.collection("notes")
            .whereEqualTo("userId", currentUser.uid)
            .whereEqualTo("date", date)
            .orderBy("timestamp")
            .get()
            .addOnSuccessListener { documents ->
                val notesList = mutableListOf<String>()
                for (doc in documents) {
                    val time = doc.getString("time") ?: ""
                    val text = doc.getString("text") ?: ""
                    val displayNote = if (time.isNotEmpty()) "$time - $text" else text
                    notesList.add(displayNote)
                }
                adapter.clear()
                adapter.addAll(notesList)
                adapter.notifyDataSetChanged()
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Błąd wczytywania notatek: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    private fun addNoteForDateFirestore(date: String, noteText: String) {
        val currentUser = auth.currentUser
        if (currentUser == null) {
            Toast.makeText(this, "Nie jesteś zalogowany", Toast.LENGTH_SHORT).show()
            return
        }

        val noteData = hashMapOf(
            "date" to date,
            "time" to "", // jeśli chcesz, możesz dodać input na godzinę i tu ją wstawić
            "text" to noteText,
            "timestamp" to Timestamp.now(),
            "userId" to currentUser.uid
        )

        db.collection("notes")
            .add(noteData)
            .addOnSuccessListener {
                Toast.makeText(this, "Notatka dodana", Toast.LENGTH_SHORT).show()
                noteInput.text.clear()
                loadNotesForDate(date)  // odśwież listę notatek
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Błąd dodawania notatki: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
